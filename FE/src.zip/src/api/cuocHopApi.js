import { docPhanHoiJson, goiApi } from './apiClient.js'

export async function layDanhSachDeXuat(token, signal) {
  const response = await goiApi('/api/cuoc-hop/de-xuat', {
    method: 'GET',
    token,
    signal,
  })

  if (!response.ok) {
    const loi = new Error('Không tải được danh sách đề xuất.')
    loi.status = response.status
    throw loi
  }

  return response.json()
}

export async function layChiTietDeXuat(cuocHopId, token, signal) {
  const response = await goiApi(`/api/cuoc-hop/${cuocHopId}/de-xuat`, {
    token,
    signal,
  })

  if (!response.ok) {
    const loi = new Error('Không tải được chi tiết đề xuất.')
    loi.status = response.status
    throw loi
  }

  return response.json()
}

export async function tiepNhanDeXuat(cuocHopId, token) {
  const response = await goiApi(`/api/cuoc-hop/${cuocHopId}/tiep-nhan`, {
    method: 'POST',
    token,
  })

  if (!response.ok) {
    const loi = new Error('Không tiếp nhận được đề xuất.')
    loi.status = response.status
    throw loi
  }

  return response.json()
}

export async function capNhatKeHoach(cuocHopId, duLieu, token) {
  const response = await goiApi(`/api/cuoc-hop/${cuocHopId}/ke-hoach`, {
    method: 'PUT',
    token,
    duLieu,
  })

  return docPhanHoiJson(response, 'Không cập nhật được kế hoạch.')
}

function docPhanHoiTaiLieu(response) {
  return docPhanHoiJson(response, 'Không xử lý được tài liệu kế hoạch.')
}

export async function layTaiLieuKeHoach(cuocHopId, token, signal) {
  const response = await goiApi(`/api/tai-lieu-ke-hoach/cuoc-hop/${cuocHopId}`, {
    token,
    signal,
  })

  return docPhanHoiTaiLieu(response)
}

export async function taiLenTaiLieuKeHoach(cuocHopId, file, token) {
  const formData = new FormData()
  formData.append('file', file)

  const response = await goiApi(`/api/tai-lieu-ke-hoach/cuoc-hop/${cuocHopId}`, {
    method: 'POST',
    token,
    body: formData,
  })

  return docPhanHoiTaiLieu(response)
}

export async function trinhKeHoach(cuocHopId, duLieu, token) {
  const response = await goiApi(`/api/quy-trinh-ke-hoach/${cuocHopId}/trinh`, {
    method: 'POST',
    token,
    duLieu,
  })

  if (!response.ok) {
    const ketQua = await response.json().catch(() => null)
    throw new Error(
      ketQua?.detail || ketQua?.message || 'Không trình duyệt được kế hoạch.',
    )
  }
}

export async function layKeHoachChoToiDuyet(token, signal) {
  const response = await goiApi('/api/quy-trinh-ke-hoach/cua-toi/cho-duyet', {
    token,
    signal,
  })

  if (!response.ok) {
    const loi = new Error('Không tải được danh sách kế hoạch chờ duyệt.')
    loi.status = response.status
    throw loi
  }

  return response.json()
}

export async function layChiTietKeHoachChoDuyet(yeuCauId, token, signal) {
  const response = await goiApi(`/api/cuoc-hop/ke-hoach/cho-duyet/${yeuCauId}`, {
    token,
    signal,
  })

  if (!response.ok) {
    const loi = new Error('Không tải được chi tiết kế hoạch.')
    loi.status = response.status
    throw loi
  }

  return response.json()
}

export async function xuLyYeuCauKeHoach(cuocHopId, yeuCauId, thaoTac, yKien, token) {
  const response = await goiApi(
    `/api/quy-trinh-ke-hoach/${cuocHopId}/yeu-cau/${yeuCauId}/${thaoTac}`,
    {
      method: 'POST',
      token,
      duLieu: { yKien },
    },
  )

  return docPhanHoiJson(response, 'Không xử lý được kế hoạch.')
}

function docPhanHoiLichHop(response) {
  return docPhanHoiJson(response, 'Không xử lý được lịch họp.')
}

export async function layLichTheoCuocHop(cuocHopId, token, signal) {
  const response = await goiApi(`/api/lich-hop/cuoc-hop/${cuocHopId}`, {
    token,
    signal,
  })

  return docPhanHoiLichHop(response)
}

export async function taoLichHop(duLieu, token) {
  const response = await goiApi('/api/lich-hop', {
    method: 'POST',
    token,
    duLieu,
  })

  return docPhanHoiLichHop(response)
}

export async function layKeHoachToiDaDuyet(token, signal) {
  const response = await goiApi('/api/quy-trinh-ke-hoach/cua-toi/da-duyet', {
    token,
    signal,
  })

  return docPhanHoiLichHop(response)
}

export async function xacNhanLichHop(lichHopId, token) {
  const response = await goiApi(`/api/lich-hop/${lichHopId}/xac-nhan`, {
    method: 'PUT',
    token,
  })

  return docPhanHoiLichHop(response)
}

export async function batDauCuocHop(cuocHopId, token) {
  const response = await goiApi(`/api/cuoc-hop/${cuocHopId}/bat-dau`, {
    method: 'POST',
    token,
  })

  return docPhanHoiJson(response, 'Không bắt đầu được cuộc họp.')
}

export async function ketThucCuocHop(cuocHopId, token) {
  const response = await goiApi(`/api/cuoc-hop/${cuocHopId}/ket-thuc`, {
    method: 'POST',
    token,
  })

  return docPhanHoiJson(
    response,
    `Không kết thúc được cuộc họp (HTTP ${response.status}).`,
  )
}
