import { useEffect, useState } from 'react'
import {
  layKetLuanChoToiPhatHanh,
  phatHanhKetLuan,
} from '../../api/ketLuanCuocHopApi.js'
import TaiLieuKetLuan from '../thuky/TaiLieuKetLuan.jsx'

export default function KetLuanChoPhatHanh({ token }) {
  const [danhSach, setDanhSach] = useState(null)
  const [loi, setLoi] = useState('')
  const [thongBao, setThongBao] = useState('')
  const [dangPhatHanhId, setDangPhatHanhId] = useState(null)

  useEffect(() => {
    const controller = new AbortController()

    layKetLuanChoToiPhatHanh(token, controller.signal)
      .then((duLieu) => {
        if (!controller.signal.aborted) setDanhSach(duLieu)
      })
      .catch((loiTai) => {
        if (!controller.signal.aborted) setLoi(loiTai.message)
      })

    return () => controller.abort()
  }, [token])

  async function xuLyPhatHanh(ketLuan) {
    if (dangPhatHanhId !== null) return

    setDangPhatHanhId(ketLuan.ketLuanId)
    setLoi('')
    setThongBao('')

    try {
      await phatHanhKetLuan(ketLuan.cuocHopId, token)
      setDanhSach((hienTai) =>
        hienTai.filter((muc) => muc.ketLuanId !== ketLuan.ketLuanId),
      )
      setThongBao(`Đã phát hành kết luận cuộc họp #${ketLuan.cuocHopId}.`)
    } catch (loiPhatHanh) {
      setLoi(loiPhatHanh.message)
    } finally {
      setDangPhatHanhId(null)
    }
  }

  return (
    <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5">
      <h2 className="text-lg font-bold">Kết luận chờ tôi phát hành</h2>

      {loi && <p role="alert" className="text-sm text-red-800">{loi}</p>}
      {thongBao && <p role="status" className="text-sm text-emerald-800">{thongBao}</p>}
      {!loi && danhSach === null && <p role="status">Đang tải kết luận…</p>}
      {danhSach?.length === 0 && <p>Hiện chưa có kết luận chờ bạn phát hành.</p>}

      {danhSach?.map((ketLuan) => (
        <details key={ketLuan.ketLuanId} className="rounded-lg border border-slate-200 p-4">
          <summary className="cursor-pointer font-semibold">
            {ketLuan.tieuDe}
          </summary>

          <div className="mt-3 space-y-3">
            <p className="whitespace-pre-wrap text-sm">
              {ketLuan.noiDung || 'Chưa có nội dung văn bản.'}
            </p>

            <TaiLieuKetLuan
              cuocHopId={ketLuan.cuocHopId}
              token={token}
              choPhepTaiLen={false}
            />

            <button
              type="button"
              disabled={dangPhatHanhId !== null}
              onClick={() => xuLyPhatHanh(ketLuan)}
              className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            >
              {dangPhatHanhId === ketLuan.ketLuanId
                ? 'Đang phát hành…'
                : 'Phát hành kết luận'}
            </button>
          </div>
        </details>
      ))}
    </section>
  )
}