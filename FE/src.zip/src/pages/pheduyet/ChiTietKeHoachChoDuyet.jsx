import { useEffect, useState } from 'react'
import {
  layChiTietKeHoachChoDuyet,
  xuLyYeuCauKeHoach,
} from '../../api/cuocHopApi.js'

export default function ChiTietKeHoachChoDuyet({
  keHoach,
  token,
  onDong,
  onDaXuLy,
}) {
  const [chiTiet, setChiTiet] = useState(null)
  const [loiTai, setLoiTai] = useState('')
  const [yKien, setYKien] = useState('')
  const [loiXuLy, setLoiXuLy] = useState('')
  const [dangXuLy, setDangXuLy] = useState(false)

  const { cuocHopId, yeuCauPheDuyetId } = keHoach

  useEffect(() => {
    const controller = new AbortController()

    layChiTietKeHoachChoDuyet(yeuCauPheDuyetId, token, controller.signal)
      .then((duLieu) => {
        if (!controller.signal.aborted) setChiTiet(duLieu)
      })
      .catch((loi) => {
        if (!controller.signal.aborted) setLoiTai(loi.message)
      })

    return () => controller.abort()
  }, [yeuCauPheDuyetId, token])

  async function xuLy(thaoTac) {
    if (dangXuLy) return

    const noiDungYKien = yKien.trim()
    setLoiXuLy('')

    if (thaoTac === 'tra-lai' && !noiDungYKien) {
      setLoiXuLy('Nhập lý do để thư ký biết cần chỉnh sửa nội dung nào.')
      return
    }

    setDangXuLy(true)

    try {
      await xuLyYeuCauKeHoach(
        cuocHopId, yeuCauPheDuyetId, thaoTac, noiDungYKien || null, token,
      )

      onDaXuLy(
        yeuCauPheDuyetId,
        thaoTac === 'phe-duyet' ? 'Đã phê duyệt kế hoạch.' : 'Đã trả lại kế hoạch cho thư ký.',
      )
    } catch (loi) {
      setLoiXuLy(loi.message)
    } finally {
      setDangXuLy(false)
    }
  }

  return (
    <section className="space-y-4 border-t border-slate-200 pt-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-semibold">Chi tiết kế hoạch</h3>
        <button
          type="button"
          onClick={onDong}
          disabled={dangXuLy}
          className="text-sm font-medium text-slate-600"
        >
          Đóng chi tiết
        </button>
      </div>

      {loiTai ? (
        <p role="alert" className="text-sm text-red-800">{loiTai}</p>
      ) : chiTiet === null ? (
        <p role="status" className="text-sm text-slate-600">Đang tải chi tiết…</p>
      ) : (
        <>
          <dl className="space-y-3 text-sm">
            {[
              ['Mục tiêu', chiTiet.mucTieu],
              ['Nội dung dự kiến', chiTiet.noiDungDuKien],
              ['Ghi chú trình', chiTiet.ghiChuTrinh],
            ].map(([nhan, giaTri]) => (
              <div key={nhan}>
                <dt className="font-semibold">{nhan}</dt>
                <dd className="mt-1 whitespace-pre-wrap">{giaTri || '—'}</dd>
              </div>
            ))}
          </dl>

          <label className="block text-sm font-medium">
            Ý kiến xử lý
            <textarea
              value={yKien}
              onChange={(event) => setYKien(event.target.value)}
              disabled={dangXuLy}
              rows={3}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
            />
          </label>

          {loiXuLy && <p role="alert" className="text-sm text-red-800">{loiXuLy}</p>}

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={dangXuLy}
              onClick={() => xuLy('phe-duyet')}
              className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            >
              Phê duyệt
            </button>
            <button
              type="button"
              disabled={dangXuLy}
              onClick={() => xuLy('tra-lai')}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold disabled:opacity-60"
            >
              Trả lại
            </button>
          </div>
        </>
      )}
    </section>
  )
}