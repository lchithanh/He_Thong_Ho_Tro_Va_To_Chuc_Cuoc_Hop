import { useEffect, useState } from 'react'
import CalendarDays from 'lucide-react/dist/esm/icons/calendar-days.mjs'
import CheckCircle2 from 'lucide-react/dist/esm/icons/check-circle-2.mjs'
import CircleDot from 'lucide-react/dist/esm/icons/circle-dot.mjs'
import Clock3 from 'lucide-react/dist/esm/icons/clock-3.mjs'
import FileClock from 'lucide-react/dist/esm/icons/file-clock.mjs'
import Inbox from 'lucide-react/dist/esm/icons/inbox.mjs'
import {
  ketThucCuocHop,
  layChiTietDeXuat,
  layDanhSachDeXuat,
  tiepNhanDeXuat,
} from '../../api/cuocHopApi.js'
import TaiLieuKeHoachThuKy from './TaiLieuKeHoachThuKy.jsx'
import FormKeHoachThuKy from './FormKeHoachThuKy.jsx'
import LichHopThuKy from './LichHopThuKy.jsx'
import DiemDanhThuKy from './DiemDanhThuKy.jsx'
import BienBanThuKy from './BienBanThuKy.jsx'
import KetLuanThuKy from './KetLuanThuKy.jsx'
import ThanhVienCuocHopThuKy from './ThanhVienCuocHopThuKy.jsx'
import DanhSachBieuQuyetChuTri from '../pheduyet/DanhSachBieuQuyetChuTri.jsx'
import TaoBieuQuyet from '../pheduyet/TaoBieuQuyet.jsx'

const TEN_PHAM_VI = {
  NOI_BO: 'Nội bộ',
  LIEN_PHONG_BAN: 'Liên phòng ban',
  TOAN_CO_QUAN: 'Toàn cơ quan',
  BEN_NGOAI: 'Bên ngoài',
}

const TEN_TRANG_THAI = {
  NHAP: 'Bản nháp',
  CHO_TIEP_NHAN: 'Chờ tiếp nhận',
  DANG_CHUAN_BI: 'Đang chuẩn bị',
  DA_DUYET: 'Đã duyệt',
  CHO_DUYET: 'Chờ duyệt',
  TU_CHOI: 'Từ chối',
  DANG_DIEN_RA: 'Đang diễn ra',
  DA_KET_THUC: 'Đã kết thúc',
  DA_HUY: 'Đã hủy',
}

const MAU_TRANG_THAI = {
  CHO_TIEP_NHAN: 'bg-amber-50 text-amber-900',
  DANG_CHUAN_BI: 'bg-amber-50 text-amber-900',
  DA_DUYET: 'bg-emerald-50 text-emerald-800',
  DANG_DIEN_RA: 'bg-emerald-50 text-emerald-800',
  TU_CHOI: 'bg-red-50 text-red-800',
  DA_HUY: 'bg-red-50 text-red-800',
}

const TABS = [
  { id: 'thong-tin', ten: 'Tổng quan' },
  { id: 'ke-hoach', ten: 'Kế hoạch' },
  { id: 'lich-hop', ten: 'Lịch họp' },
  { id: 'diem-danh', ten: 'Điểm danh' },
  { id: 'bieu-quyet', ten: 'Biểu quyết' },
  { id: 'bien-ban', ten: 'Biên bản' },
  { id: 'ket-luan', ten: 'Kết luận' },
]

function NhanTrangThai({ trangThai }) {
  const mau = MAU_TRANG_THAI[trangThai] ?? 'bg-slate-100 text-slate-700'

  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold ${mau}`}>
      <span aria-hidden="true" className="size-1.5 rounded-full bg-current" />
      {TEN_TRANG_THAI[trangThai] ?? trangThai ?? '—'}
    </span>
  )
}

export default function DanhSachDeXuatThuKy({ token, nguoiDung }) {
  const [danhSach, setDanhSach] = useState(null)
  const [loi, setLoi] = useState('')
  const [cuocHopDangXem, setCuocHopDangXem] = useState(null)
  const [tuKhoa, setTuKhoa] = useState('')
  const [phamVi, setPhamVi] = useState('')
  const [trangThai, setTrangThai] = useState('')


  useEffect(() => {
    if (!token) return

    const controller = new AbortController()

    async function taiDanhSach() {
      try {
        const duLieu = await layDanhSachDeXuat(token, controller.signal)
        if (!controller.signal.aborted) setDanhSach(duLieu)
      } catch (loiTaiDanhSach) {
        if (controller.signal.aborted) return

        setLoi(
          loiTaiDanhSach.status === 403
            ? 'Tài khoản không có quyền xem danh sách đề xuất.'
            : 'Không tải được danh sách đề xuất. Hãy tải lại trang để thử lại.',
        )
      }
    }

    taiDanhSach()
    return () => controller.abort()
  }, [token])

  if (cuocHopDangXem !== null) {
    return (
      <ChiTietDeXuat
        cuocHopId={cuocHopDangXem}
        token={token}
        nguoiDung={nguoiDung}
        onQuayLai={() => setCuocHopDangXem(null)}
        onDaTiepNhan={(cuocHopId, thayDoi) => {
          setDanhSach((danhSachHienTai) =>
            danhSachHienTai.map((deXuat) =>
              deXuat.cuocHopId === cuocHopId
                ? { ...deXuat, ...thayDoi }
                : deXuat,
            ),
          )
        }}
      />
    )
  }

  const timKiem = tuKhoa.trim().toLocaleLowerCase('vi')
  const danhSachHienThi = danhSach?.filter((deXuat) => {
    const thongTin = `${deXuat.tieuDe ?? ''} ${deXuat.maCuocHop || deXuat.cuocHopId}`
    return (!phamVi || deXuat.phamViCuocHop === phamVi)
      && (!trangThai || deXuat.trangThai === trangThai)
      && thongTin.toLocaleLowerCase('vi').includes(timKiem)
  })

  return (
    <div className="space-y-5">
      <section className="space-y-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-800">Quản lý hồ sơ</p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900">Đề xuất cuộc họp</h1>
            <p className="mt-1 text-sm text-slate-500">Theo dõi tiến độ xử lý từ lúc tiếp nhận đến khi kết thúc.</p>
          </div>
          {danhSach && (
            <span className="rounded-full bg-white px-3 py-1.5 text-sm font-semibold text-slate-600 shadow-sm ring-1 ring-slate-200">
              {danhSachHienThi.length} / {danhSach.length} hồ sơ
            </span>
          )}
        </div>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
          {[
            { ten: 'Chờ tiếp nhận', ma: 'CHO_TIEP_NHAN', BieuTuong: Inbox, mau: 'bg-amber-50 text-amber-700' },
            { ten: 'Đang chuẩn bị', ma: 'DANG_CHUAN_BI', BieuTuong: FileClock, mau: 'bg-sky-50 text-sky-700' },
            { ten: 'Chờ duyệt', ma: 'CHO_DUYET', BieuTuong: Clock3, mau: 'bg-violet-50 text-violet-700' },
            { ten: 'Đã duyệt', ma: 'DA_DUYET', BieuTuong: CheckCircle2, mau: 'bg-emerald-50 text-emerald-700' },
            { ten: 'Đang diễn ra', ma: 'DANG_DIEN_RA', BieuTuong: CircleDot, mau: 'bg-rose-50 text-rose-700' },
            { ten: 'Đã kết thúc', ma: 'DA_KET_THUC', BieuTuong: CalendarDays, mau: 'bg-slate-100 text-slate-600' },
          ].map(({ ten, ma, BieuTuong, mau }) => (
            <button
              key={ma}
              type="button"
              onClick={() => setTrangThai((hienTai) => hienTai === ma ? '' : ma)}
              aria-pressed={trangThai === ma}
              className={`rounded-2xl border p-4 text-left shadow-sm shadow-slate-900/[0.02] transition hover:-translate-y-0.5 hover:shadow-md ${
                trangThai === ma
                  ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-100'
                  : 'border-slate-200/80 bg-white'
              }`}
            >
              <span className={`grid size-9 place-items-center rounded-xl ${mau}`}><BieuTuong size={18} /></span>
              <span className="mt-3 block text-2xl font-bold tabular-nums text-slate-900">
                {danhSach ? danhSach.filter((deXuat) => deXuat.trangThai === ma).length : '—'}
              </span>
              <span className="mt-1 block text-xs font-semibold text-slate-600">{ten}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="min-w-0 rounded-2xl border border-slate-200/80 bg-white p-4 shadow-sm shadow-slate-900/[0.02] sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Danh sách cuộc họp</h2>
            <p className="mt-1 text-sm text-slate-500">Tìm kiếm, lọc trạng thái và mở hồ sơ chi tiết.</p>
          </div>
        </div>

        {danhSach?.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-3">
          <label>
            <span className="sr-only">Tìm đề xuất theo tên hoặc mã cuộc họp</span>
            <input
              type="search"
              placeholder="Tìm tên hoặc mã cuộc họp…"
              value={tuKhoa}
              onChange={(event) => setTuKhoa(event.target.value)}
              className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none transition focus:border-emerald-600 focus:ring-4 focus:ring-emerald-100 sm:w-72"
            />
          </label>
          <label>
            <span className="sr-only">Phạm vi cuộc họp</span>
            <select value={phamVi} onChange={(event) => setPhamVi(event.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-emerald-600 focus:ring-4 focus:ring-emerald-100">
              <option value="">Tất cả phạm vi</option>
              {Object.entries(TEN_PHAM_VI).map(([ma, ten]) => (
                <option key={ma} value={ma}>{ten}</option>
              ))}
            </select>
          </label>
          <label>
            <span className="sr-only">Lọc theo trạng thái</span>
            <select value={trangThai} onChange={(event) => setTrangThai(event.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-emerald-600 focus:ring-4 focus:ring-emerald-100">
              <option value="">Tất cả trạng thái</option>
              {Object.entries(TEN_TRANG_THAI).map(([ma, ten]) => (
                <option key={ma} value={ma}>{ten}</option>
              ))}
            </select>
          </label>
        </div>
      )}

      {loi ? (
        <p role="alert" className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-800">
          {loi}
        </p>
      ) : danhSach === null ? (
        <p role="status" className="mt-4 text-sm text-slate-600">
          Đang tải danh sách…
        </p>
      ) : danhSach.length === 0 ? (
        <p className="mt-4 text-sm text-slate-600">Chưa có đề xuất cuộc họp.</p>
      ) : danhSachHienThi.length === 0 ? (
        <p className="mt-4 text-sm text-slate-600">Không tìm thấy đề xuất phù hợp.</p>
      ) : (
        <div className="mt-4 overflow-x-auto rounded-xl border border-slate-200 focus-visible:outline-2 focus-visible:outline-emerald-700" tabIndex={0} role="region" aria-label="Danh sách đề xuất cuộc họp">
          <table className="w-full min-w-[680px] text-left text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th scope="col" className="px-3 py-3">Cuộc họp</th>
                <th scope="col" className="px-3 py-3">Người đề xuất</th>
                <th scope="col" className="px-3 py-3">Phạm vi</th>
                <th scope="col" className="px-3 py-3">Trạng thái</th>
                <th scope="col" className="px-3 py-3">Thao tác</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {danhSachHienThi.map((deXuat) => (
              
                <tr key={deXuat.cuocHopId} className="transition hover:bg-slate-50/80">
                  <td className="px-3 py-3">
                    <p className="font-medium">{deXuat.tieuDe}</p>
                    <p className="text-xs text-slate-600">
                      {deXuat.maCuocHop || `#${deXuat.cuocHopId}`}
                    </p>
                  </td>
                  <td className="px-3 py-3">{deXuat.tenNguoiDeXuat || '—'}</td>
                  <td className="px-3 py-3">
                    {TEN_PHAM_VI[deXuat.phamViCuocHop] ?? deXuat.phamViCuocHop ?? '—'}
                  </td>
                  <td className="px-3 py-3">
                    <NhanTrangThai trangThai={deXuat.trangThai} />
                  </td>
                  <td className="px-3 py-3">
                    <button
                      type="button"
                      onClick={() => setCuocHopDangXem(deXuat.cuocHopId)}
                      className="whitespace-nowrap rounded-lg border border-emerald-200 px-3 py-1.5 font-semibold text-emerald-800 transition hover:bg-emerald-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700"
                    >
                      Xem chi tiết
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      </section>
    </div>
  )
}

function ChiTietDeXuat({ cuocHopId, token, nguoiDung, onQuayLai, onDaTiepNhan }) {
  const [chiTiet, setChiTiet] = useState(null)
  const [loi, setLoi] = useState('')
  const [dangTiepNhan, setDangTiepNhan] = useState(false)
  const [loiTiepNhan, setLoiTiepNhan] = useState('')
  const [thongBaoTiepNhan, setThongBaoTiepNhan] = useState('')
  const [dangKetThuc, setDangKetThuc] = useState(false)
  const [loiKetThuc, setLoiKetThuc] = useState('')
  const [tabHienTai, setTabHienTai] = useState('thong-tin')

  useEffect(() => {
    const controller = new AbortController()

    async function taiChiTiet() {
      try {
        const duLieu = await layChiTietDeXuat(cuocHopId, token, controller.signal)
        if (!controller.signal.aborted) setChiTiet(duLieu)
      } catch (loiTaiChiTiet) {
        if (controller.signal.aborted) return

        const thongBao = {
          403: 'Bạn không có quyền xem đề xuất này.',
          404: 'Không tìm thấy đề xuất cuộc họp.',
        }

        setLoi(thongBao[loiTaiChiTiet.status] || 'Không tải được chi tiết đề xuất.')
      }
    }

    taiChiTiet()
    return () => controller.abort()
  }, [cuocHopId, token])

  async function xuLyTiepNhan() {
    if (dangTiepNhan || chiTiet?.trangThai !== 'CHO_TIEP_NHAN') return

    setDangTiepNhan(true)
    setLoiTiepNhan('')

    try {
      const ketQua = await tiepNhanDeXuat(cuocHopId, token)
      const thayDoi = {
        trangThai: ketQua.trangThai,
        buocXuLyHienTai: ketQua.buocXuLyHienTai,
      }

      setChiTiet((hienTai) => ({ ...hienTai, ...thayDoi }))
      onDaTiepNhan(cuocHopId, thayDoi)
      setThongBaoTiepNhan(ketQua.message || 'Tiếp nhận đề xuất thành công.')
    } catch (loiKhiTiepNhan) {
      const thongBao = {
        401: 'Phiên đăng nhập không còn hợp lệ.',
        403: 'Tài khoản này không có quyền tiếp nhận đề xuất.',
        409: 'Trạng thái đề xuất đã thay đổi. Hãy tải lại trang.',
      }

      setLoiTiepNhan(
        thongBao[loiKhiTiepNhan.status] || 'Không tiếp nhận được đề xuất.',
      )
    } finally {
      setDangTiepNhan(false)
    }
  }

  async function xuLyKetThuc() {
    if (dangKetThuc || chiTiet?.trangThai !== 'DANG_DIEN_RA') return

    setDangKetThuc(true)
    setLoiKetThuc('')

    try {
      const ketQua = await ketThucCuocHop(cuocHopId, token)
      const thayDoi = {
        trangThai: ketQua.trangThai,
        buocXuLyHienTai: ketQua.buocXuLyHienTai,
      }

      setChiTiet((hienTai) => ({ ...hienTai, ...thayDoi }))
      onDaTiepNhan(cuocHopId, thayDoi)
    } catch (loi) {
      setLoiKetThuc(loi.message)
    } finally {
      setDangKetThuc(false)
    }
  }

  const dangLapKeHoach = chiTiet?.trangThai === 'DANG_CHUAN_BI'
    && chiTiet.buocXuLyHienTai === 'LAP_KE_HOACH'
  const dangToChuc = chiTiet?.trangThai === 'DA_DUYET'
    && chiTiet.buocXuLyHienTai === 'THU_KY_TO_CHUC'
  const dangDienRa = chiTiet?.trangThai === 'DANG_DIEN_RA'
  const daKetThuc = chiTiet?.trangThai === 'DA_KET_THUC'
  const laThuKy = nguoiDung?.maVaiTro === 'THU_KY'
  const laChuTri = Number(nguoiDung?.nguoiDungId) === Number(chiTiet?.nguoiChuTriId)
  const cacTab = TABS.filter(({ id }) => {
    if (id === 'ke-hoach') return dangLapKeHoach
    if (id === 'lich-hop') return dangToChuc
    if (id === 'diem-danh') return dangDienRa || daKetThuc
    if (id === 'bieu-quyet') return laChuTri && ['DA_DUYET', 'DANG_DIEN_RA', 'DA_KET_THUC'].includes(chiTiet?.trangThai)
    if (id === 'bien-ban' || id === 'ket-luan') return daKetThuc
    return true
  })

  const tabHienThi = cacTab.some((tab) => tab.id === tabHienTai)
    ? tabHienTai
    : 'thong-tin'

  return (
    <div className="space-y-5">
      <button
        type="button"
        onClick={onQuayLai}
        disabled={dangTiepNhan}
        className="inline-flex items-center gap-2 rounded-lg px-2 py-1 text-sm font-semibold text-emerald-800 transition hover:bg-emerald-50 disabled:opacity-60"
      >
        <span aria-hidden="true">←</span> Quay lại danh sách
      </button>

      {loi ? (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">{loi}</p>
      ) : chiTiet === null ? (
        <p role="status" className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-600">Đang tải chi tiết cuộc họp…</p>
      ) : (
        <>
          <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
            <section className="min-w-0 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm shadow-slate-900/[0.02]">
              <div className="border-b border-slate-100 p-5 sm:p-7">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="min-w-0">
                    <p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-800">Hồ sơ cuộc họp</p>
                    <h1 className="mt-2 break-words text-2xl font-bold tracking-tight text-slate-900 md:text-3xl">{chiTiet.tieuDe}</h1>
                    <p className="mt-2 text-sm text-slate-500">
                      {chiTiet.maCuocHop || `Mã cuộc họp #${cuocHopId}`}
                      {chiTiet.tenNguoiDeXuat ? ` · Đề xuất bởi ${chiTiet.tenNguoiDeXuat}` : ''}
                    </p>
                  </div>
                  <NhanTrangThai trangThai={chiTiet.trangThai} />
                </div>
              </div>

              <nav
                role="tablist"
                aria-label="Chi tiết cuộc họp"
                className="flex gap-1 overflow-x-auto border-b border-slate-100 px-4 pt-3 sm:px-6"
              >
                {cacTab.map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    id={`tab-${tab.id}`}
                    aria-selected={tabHienThi === tab.id}
                    aria-controls={`panel-${tab.id}`}
                    onClick={() => setTabHienTai(tab.id)}
                    className={`shrink-0 border-b-2 px-3 py-3 text-sm font-semibold transition ${
                      tabHienThi === tab.id
                        ? 'border-emerald-700 text-emerald-800'
                        : 'border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {tab.ten}
                  </button>
                ))}
              </nav>

              <div
                role="tabpanel"
                id={`panel-${tabHienThi}`}
                aria-labelledby={`tab-${tabHienThi}`}
                className="space-y-5 p-5 sm:p-6"
              >
                {tabHienThi === 'thong-tin' && (
                  <>
                    <dl className="grid gap-4 sm:grid-cols-2">
                      <div className="rounded-xl bg-slate-50 p-4">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">Mục tiêu</dt>
                        <dd className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-800">{chiTiet.mucTieu || 'Chưa nhập'}</dd>
                      </div>
                      <div className="rounded-xl bg-slate-50 p-4">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">Nội dung dự kiến</dt>
                        <dd className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-800">{chiTiet.noiDungDuKien || 'Chưa nhập'}</dd>
                      </div>
                      <div className="rounded-xl bg-slate-50 p-4">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">Phạm vi</dt>
                        <dd className="mt-2 text-sm font-medium text-slate-800">{TEN_PHAM_VI[chiTiet.phamViCuocHop] || chiTiet.phamViCuocHop || '—'}</dd>
                      </div>
                      <div className="rounded-xl bg-slate-50 p-4">
                        <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">Hình thức</dt>
                        <dd className="mt-2 text-sm font-medium text-slate-800">{chiTiet.loaiHinh === 'TRUC_TIEP' ? 'Trực tiếp' : chiTiet.loaiHinh === 'TRUC_TUYEN' ? 'Trực tuyến' : chiTiet.loaiHinh || '—'}</dd>
                      </div>
                    </dl>

                    {chiTiet.trangThai === 'CHO_TIEP_NHAN' && (
                      <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
                        <p className="text-sm font-semibold text-amber-950">Đề xuất đang chờ thư ký tiếp nhận</p>
                        <p className="mt-1 text-sm text-amber-800">Tiếp nhận hồ sơ để bắt đầu chuẩn bị kế hoạch cuộc họp.</p>
                        <button
                          type="button"
                          onClick={xuLyTiepNhan}
                          disabled={dangTiepNhan}
                          className="mt-4 rounded-lg bg-emerald-800 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-900 disabled:opacity-60"
                        >
                          {dangTiepNhan ? 'Đang tiếp nhận…' : 'Tiếp nhận đề xuất'}
                        </button>
                      </div>
                    )}

                    {dangDienRa && (
                      <div className="rounded-xl border border-rose-200 bg-rose-50 p-4">
                        <p className="text-sm font-semibold text-rose-950">Cuộc họp đang diễn ra</p>
                        <p className="mt-1 text-sm text-rose-800">Kết thúc cuộc họp sau khi hoàn tất nội dung và biểu quyết.</p>
                        {loiKetThuc && <p role="alert" className="mt-3 text-sm text-red-800">{loiKetThuc}</p>}
                        <button
                          type="button"
                          onClick={xuLyKetThuc}
                          disabled={dangKetThuc}
                          className="mt-4 rounded-lg bg-rose-700 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-rose-800 disabled:opacity-60"
                        >
                          {dangKetThuc ? 'Đang kết thúc…' : 'Kết thúc cuộc họp'}
                        </button>
                      </div>
                    )}

                    {loiTiepNhan && <p role="alert" className="text-sm text-red-800">{loiTiepNhan}</p>}
                    {thongBaoTiepNhan && <p role="status" className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">{thongBaoTiepNhan}</p>}
                  </>
                )}

                {tabHienThi === 'ke-hoach' && dangLapKeHoach && (
                  <div className="space-y-6">
                    <FormKeHoachThuKy
                      chiTiet={chiTiet}
                      token={token}
                      onDaLuu={(duLieu) => {
                        setChiTiet((hienTai) => ({ ...hienTai, ...duLieu }))
                        onDaTiepNhan(cuocHopId, duLieu)
                      }}
                    />
                    <TaiLieuKeHoachThuKy
                      cuocHopId={cuocHopId}
                      token={token}
                      onDaTrinh={(chiTietMoi) => {
                        setChiTiet(chiTietMoi)
                        onDaTiepNhan(cuocHopId, chiTietMoi)
                      }}
                    />
                  </div>
                )}

                {tabHienThi === 'lich-hop' && dangToChuc && (
                  <LichHopThuKy
                    cuocHopId={cuocHopId}
                    loaiHinh={chiTiet.loaiHinh}
                    token={token}
                    onDaBatDau={(thayDoi) => {
                      setChiTiet((hienTai) => ({ ...hienTai, ...thayDoi }))
                      onDaTiepNhan(cuocHopId, thayDoi)
                    }}
                  />
                )}

                {tabHienThi === 'diem-danh' && (dangDienRa || daKetThuc) && (
                  <DiemDanhThuKy cuocHopId={cuocHopId} token={token} readOnly={daKetThuc} />
                )}

                {tabHienThi === 'bieu-quyet' && laChuTri && (
                  daKetThuc ? (
                    <DanhSachBieuQuyetChuTri
                      cuocHopId={cuocHopId}
                      token={token}
                      dangDienRa={false}
                      lanTao={0}
                    />
                  ) : (
                    <TaoBieuQuyet
                      key={cuocHopId}
                      nguoiDung={{ ...nguoiDung, token }}
                      cuocHopId={cuocHopId}
                    />
                  )
                )}

                {tabHienThi === 'bien-ban' && daKetThuc && (
                  <BienBanThuKy
                    key={`bien-ban-${cuocHopId}`}
                    cuocHopId={cuocHopId}
                    tieuDeCuocHop={chiTiet.tieuDe}
                    token={token}
                  />
                )}

                {tabHienThi === 'ket-luan' && daKetThuc && (
                  <KetLuanThuKy
                    key={`ket-luan-${cuocHopId}`}
                    cuocHopId={cuocHopId}
                    tieuDeCuocHop={chiTiet.tieuDe}
                    token={token}
                  />
                )}
              </div>
            </section>

            {laThuKy && (dangToChuc || dangDienRa || daKetThuc) && (
              <aside className="space-y-4 xl:sticky xl:top-24">
                <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm shadow-slate-900/[0.02]">
                  <div className="mb-4">
                    <p className="text-xs font-bold uppercase tracking-[0.14em] text-emerald-800">Thành viên</p>
                    <h2 className="mt-1 text-lg font-bold text-slate-900">Mời tham dự</h2>
                    <p className="mt-1 text-sm leading-5 text-slate-500">Chọn người tham gia và theo dõi phản hồi lời mời.</p>
                  </div>
                  <ThanhVienCuocHopThuKy cuocHopId={cuocHopId} token={token} />
                </div>
              </aside>
            )}
          </div>
        </>
      )}
    </div>
  )
}
