import { useEffect, useState } from 'react'
import {
  layKetLuanTheoCuocHop,
  taoKetLuanNhap,
} from '../../api/ketLuanCuocHopApi.js'
import TaiLieuKetLuan from './TaiLieuKetLuan.jsx'

const LOP_TRUONG = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2'

const TEN_TRANG_THAI = {
  NHAP: 'Bản nháp',
  DA_PHAT_HANH: 'Đã phát hành',
}

export default function KetLuanThuKy({ cuocHopId, tieuDeCuocHop, token }) {
  const [ketLuan, setKetLuan] = useState(undefined)
  const [loiTai, setLoiTai] = useState('')
  const [loiLuu, setLoiLuu] = useState('')
  const [dangLuu, setDangLuu] = useState(false)

  useEffect(() => {
    const controller = new AbortController()

    layKetLuanTheoCuocHop(cuocHopId, token, controller.signal)
      .then((duLieu) => {
        if (!controller.signal.aborted) setKetLuan(duLieu)
      })
      .catch((loi) => {
        if (!controller.signal.aborted) setLoiTai(loi.message)
      })

    return () => controller.abort()
  }, [cuocHopId, token])

  async function xuLyLuu(event) {
    event.preventDefault()
    if (dangLuu) return

    const form = new FormData(event.currentTarget)
    const tieuDe = form.get('tieuDe').trim()
    const noiDung = form.get('noiDung').trim()

    setLoiLuu('')

    if (!tieuDe) {
      setLoiLuu('Vui lòng nhập tiêu đề kết luận.')
      return
    }

    setDangLuu(true)

    try {
      const ketLuanMoi = await taoKetLuanNhap(
        cuocHopId,
        { tieuDe, noiDung: noiDung || null },
        token,
      )
      setKetLuan(ketLuanMoi)
    } catch (loi) {
      setLoiLuu(loi.message)
    } finally {
      setDangLuu(false)
    }
  }

  return (
    <section className="space-y-4 border-t border-slate-200 pt-5">
      <h3 className="font-semibold">Kết luận cuộc họp</h3>

      {loiTai ? (
        <p role="alert" className="text-sm text-red-800">{loiTai}</p>
      ) : ketLuan === undefined ? (
        <p role="status" className="text-sm text-slate-600">Đang tải kết luận…</p>
      ) : ketLuan === null ? (
        <form onSubmit={xuLyLuu} className="space-y-4">
          <label className="block text-sm font-medium">
            Tiêu đề kết luận
            <input
              name="tieuDe"
              defaultValue={`Kết luận cuộc họp: ${tieuDeCuocHop || cuocHopId}`.slice(0, 255)}
              maxLength={255}
              required
              className={LOP_TRUONG}
            />
          </label>

          <label className="block text-sm font-medium">
            Nội dung kết luận
            <textarea name="noiDung" rows={5} className={LOP_TRUONG} />
          </label>

          {loiLuu && <p role="alert" className="text-sm text-red-800">{loiLuu}</p>}

          <button
            type="submit"
            disabled={dangLuu}
            className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
          >
            {dangLuu ? 'Đang lưu…' : 'Lưu nháp kết luận'}
          </button>
        </form>
      ) : (
        <div className="space-y-3 rounded-lg border border-slate-200 p-4">
          <h4 className="font-semibold">{ketLuan.tieuDe}</h4>
          <p className="text-sm text-slate-600">
            Kết luận #{ketLuan.ketLuanId} ·{' '}
            {TEN_TRANG_THAI[ketLuan.trangThai] ?? ketLuan.trangThai}
          </p>

          <p className="whitespace-pre-wrap text-sm">
            {ketLuan.noiDung || 'Chưa có nội dung văn bản.'}
          </p>

          {ketLuan.hanPhatHanh && (
            <p className="text-sm text-slate-600">
              Hạn phát hành {ketLuan.hanPhatHanh}
              {ketLuan.quaHanPhatHanh && ' · Quá hạn'}
            </p>
          )}
          <TaiLieuKetLuan
            cuocHopId={cuocHopId}
            token={token}
            choPhepTaiLen={ketLuan.trangThai === 'NHAP'}
            />
        </div>
      )}
    </section>
  )
}