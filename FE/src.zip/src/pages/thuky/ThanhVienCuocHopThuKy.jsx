import { useEffect, useState } from 'react'
import Building2 from 'lucide-react/dist/esm/icons/building-2.mjs'
import UserPlus from 'lucide-react/dist/esm/icons/user-plus.mjs'
import Users from 'lucide-react/dist/esm/icons/users.mjs'
import {
  layNguoiCoTheMoi,
  layThanhVienCuocHop,
  moiThanhVienCuocHop,
} from '../../api/thanhVienCuocHopApi.js'

const TEN_TRANG_THAI_MOI = {
  CHO_PHAN_HOI: 'Chờ phản hồi',
  DA_XAC_NHAN: 'Đã xác nhận',
  TU_CHOI: 'Từ chối',
  DA_HUY: 'Đã hủy',
}

export default function ThanhVienCuocHopThuKy({ cuocHopId, token }) {
  const [danhSach, setDanhSach] = useState(null)
  const [lanTai, setLanTai] = useState(0)
  const [dangMoi, setDangMoi] = useState(false)
  const [loiTai, setLoiTai] = useState('')
  const [loiMoi, setLoiMoi] = useState('')
  const [thongBao, setThongBao] = useState('')
  const [nguoiCoTheMoi, setNguoiCoTheMoi] = useState(null)
  const [loiNguoiCoTheMoi, setLoiNguoiCoTheMoi] = useState('')

  useEffect(() => {
    const controller = new AbortController()

    layThanhVienCuocHop(cuocHopId, token, controller.signal)
      .then((duLieu) => {
        if (controller.signal.aborted) return
        setDanhSach(duLieu)
        setLoiTai('')
      })
      .catch((loi) => {
        if (!controller.signal.aborted) setLoiTai(loi.message)
      })

    layNguoiCoTheMoi(cuocHopId, token, controller.signal)
      .then((duLieu) => {
        if (controller.signal.aborted) return
        setNguoiCoTheMoi(duLieu)
        setLoiNguoiCoTheMoi('')
      })
      .catch((loi) => {
        if (controller.signal.aborted) return
        setNguoiCoTheMoi(null)
        setLoiNguoiCoTheMoi(loi.message)
      })

    return () => controller.abort()
  }, [cuocHopId, token, lanTai])

  async function xuLyMoi(event) {
    event.preventDefault()
    if (dangMoi) return

    const form = event.currentTarget
    const nguoiDuocMoiId = Number(new FormData(form).get('nguoiDuocMoiId'))

    setDangMoi(true)
    setLoiMoi('')
    setThongBao('')

    try {
      await moiThanhVienCuocHop(cuocHopId, nguoiDuocMoiId, token)
      form.reset()
      setThongBao('Đã gửi lời mời tham dự.')
      setLanTai((hienTai) => hienTai + 1)
    } catch (loi) {
      setLoiMoi(loi.message)
    } finally {
      setDangMoi(false)
    }
  }

  return (
    <section className="space-y-4">
      <form onSubmit={xuLyMoi} className="space-y-3">
        <label className="block text-sm font-semibold text-slate-700">
          Chọn thành viên
          <select
            name="nguoiDuocMoiId"
            defaultValue=""
            required
            disabled={dangMoi || !nguoiCoTheMoi?.length}
            className="mt-1.5 block w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-normal text-slate-800 outline-none transition focus:border-emerald-600 focus:ring-4 focus:ring-emerald-100 disabled:bg-slate-50"
          >
            <option value="">
              {loiNguoiCoTheMoi
                ? 'Không tải được danh sách'
                : nguoiCoTheMoi === null
                  ? 'Đang tải người dùng…'
                  : nguoiCoTheMoi.length === 0
                    ? 'Không còn người có thể mời'
                    : 'Chọn theo họ tên'}
            </option>
            {nguoiCoTheMoi?.map((nguoi) => (
              <option key={nguoi.nguoiDungId} value={nguoi.nguoiDungId}>
                {nguoi.hoTen} · {nguoi.tenPhongBan || 'Chưa có phòng ban'}
              </option>
            ))}
          </select>
        </label>

        <button
          type="submit"
          disabled={dangMoi || !nguoiCoTheMoi?.length}
          className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-800 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-900 disabled:cursor-not-allowed disabled:opacity-55"
        >
          <UserPlus size={16} />
          {dangMoi ? 'Đang gửi lời mời…' : 'Mời thành viên'}
        </button>
      </form>

      {loiNguoiCoTheMoi && <p role="alert" className="rounded-lg bg-red-50 p-2.5 text-xs leading-5 text-red-800">{loiNguoiCoTheMoi}</p>}
      {loiMoi && <p role="alert" className="rounded-lg bg-red-50 p-2.5 text-xs leading-5 text-red-800">{loiMoi}</p>}
      {loiTai && <p role="alert" className="rounded-lg bg-red-50 p-2.5 text-xs leading-5 text-red-800">{loiTai}</p>}
      {thongBao && <p role="status" className="rounded-lg bg-emerald-50 p-2.5 text-xs leading-5 text-emerald-800">{thongBao}</p>}

      <div className="border-t border-slate-100 pt-4">
        <div className="mb-3 flex items-center justify-between gap-2">
          <h3 className="text-sm font-bold text-slate-900">Danh sách thành viên</h3>
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-600">
            <Users size={13} />
            {danhSach?.length ?? '—'}
          </span>
        </div>

        {!loiTai && danhSach === null && (
          <p role="status" className="text-sm text-slate-500">Đang tải thành viên…</p>
        )}
        {danhSach?.length === 0 && (
          <p className="text-sm text-slate-500">Chưa có thành viên được mời.</p>
        )}
        {danhSach?.length > 0 && (
          <ul className="max-h-72 space-y-2 overflow-y-auto pr-1">
            {danhSach.map((thanhVien) => (
              <li key={thanhVien.nguoiDungId} className="flex items-start gap-2.5 rounded-xl bg-slate-50 p-3">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-white text-emerald-800 ring-1 ring-slate-200">
                  <Building2 size={15} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-xs font-semibold text-slate-800">{thanhVien.hoTen}</span>
                  <span className="mt-1 block text-[11px] text-slate-500">
                    {thanhVien.vaiTroTaiCuocHop === 'THU_KY'
                      ? 'Thư ký'
                      : TEN_TRANG_THAI_MOI[thanhVien.trangThaiMoi] || thanhVien.trangThaiMoi}
                  </span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  )
}
