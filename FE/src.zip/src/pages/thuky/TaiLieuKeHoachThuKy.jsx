import { useEffect, useState } from 'react'
import {
  layChiTietDeXuat,
  layTaiLieuKeHoach,
  taiLenTaiLieuKeHoach,
  trinhKeHoach,
} from '../../api/cuocHopApi.js'

export default function TaiLieuKeHoachThuKy({ cuocHopId, token, onDaTrinh }) {
  const [danhSach, setDanhSach] = useState(null)
  const [lanTai, setLanTai] = useState(0)
  const [dangTaiLen, setDangTaiLen] = useState(false)
  const [loiDanhSach, setLoiDanhSach] = useState('')
  const [loiTaiLen, setLoiTaiLen] = useState('')

  const [dangTrinh, setDangTrinh] = useState(false)
  const [daTrinh, setDaTrinh] = useState(false)
  const [loiTrinh, setLoiTrinh] = useState('')

    
  useEffect(() => {
    const controller = new AbortController()

    async function taiDanhSach() {
      try {
        const duLieu = await layTaiLieuKeHoach(
          cuocHopId, token, controller.signal,
        )
        if (controller.signal.aborted) return

        setDanhSach(duLieu)
        setLoiDanhSach('')
      } catch (loi) {
        if (!controller.signal.aborted) setLoiDanhSach(loi.message)
      }
    }

    taiDanhSach()
    return () => controller.abort()
  }, [cuocHopId, token, lanTai])

  async function xuLyTaiLen(event) {
    event.preventDefault()
    if (dangTaiLen) return

    const form = event.currentTarget
    const file = new FormData(form).get('file')

    if (!file?.name) {
      setLoiTaiLen('Vui lòng chọn tài liệu.')
      return
    }

    setDangTaiLen(true)
    setLoiTaiLen('')

    try {
      await taiLenTaiLieuKeHoach(cuocHopId, file, token)
      form.reset()
      setLanTai((lanHienTai) => lanHienTai + 1)
    } catch (loi) {
      setLoiTaiLen(loi.message)
    } finally {
      setDangTaiLen(false)
    }
  }

  // Giữ các state và hàm hiện có ngay bên dưới.

  async function xuLyTrinh(event) {
  event.preventDefault()
  if (dangTrinh || daTrinh || dangTaiLen) return

  const form = new FormData(event.currentTarget)
  const lanhDaoDuyetId = form.get('lanhDaoDuyetId')

  const duLieu = {
    taiLieuIds: form.getAll('taiLieuIds').map(Number),
    ghiChuTrinh: form.get('ghiChuTrinh').trim() || null,
    lanhDaoDuyetId: lanhDaoDuyetId ? Number(lanhDaoDuyetId) : null,
  }

  setDangTrinh(true)
  setLoiTrinh('')

  try {
    await trinhKeHoach(cuocHopId, duLieu, token)
    setDaTrinh(true)
  } catch (loi) {
    setLoiTrinh(loi.message)
    setDangTrinh(false)
    return
  }

  try {
    const chiTietMoi = await layChiTietDeXuat(cuocHopId, token)
    onDaTrinh(chiTietMoi)
  } catch {
    setLoiTrinh('Đã trình kế hoạch. Hãy tải lại trang để xem bước xử lý mới.')
  } finally {
    setDangTrinh(false)
  }
}
  return (
    <section className="space-y-4 border-t border-slate-200 pt-5">
      <h3 className="font-semibold">Tài liệu kế hoạch</h3>

      <form onSubmit={xuLyTaiLen} className="flex flex-wrap items-end gap-3">
        <label className="grid gap-1 text-sm font-medium">
          Chọn tài liệu
          <input
            name="file"
            type="file"
            accept=".pdf,.doc,.docx,.xls,.xlsx"
            required
            className="max-w-full rounded-lg border border-slate-300 p-2"
          />
        </label>

        <button
          type="submit"
          disabled={dangTaiLen}
          className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          {dangTaiLen ? 'Đang tải lên…' : 'Tải lên'}
        </button>
      </form>

      {loiTaiLen && <p role="alert" className="text-sm text-red-800">{loiTaiLen}</p>}

      {loiDanhSach ? (
        <p role="alert" className="text-sm text-red-800">{loiDanhSach}</p>
      ) : danhSach === null ? (
        <p role="status" className="text-sm text-slate-600">Đang tải tài liệu…</p>
      ) : danhSach.length === 0 ? (
        <p className="text-sm text-slate-600">Chưa có tài liệu kế hoạch.</p>
      ) : (
        <ul className="divide-y divide-slate-200 text-sm">
          {danhSach.map((taiLieu) => (
            <li key={taiLieu.taiLieuId} className="break-all py-2">
              {taiLieu.tenFileGoc || taiLieu.tenTaiLieu}
            </li>
          ))}
        </ul>
      )}
      {danhSach !== null && !loiDanhSach && (
  <form onSubmit={xuLyTrinh} className="space-y-4 border-t border-slate-200 pt-4">
    <h4 className="font-semibold">Trình duyệt kế hoạch</h4>

    <fieldset disabled={dangTrinh || daTrinh} className="space-y-3">
      {danhSach.length > 0 && (
        <fieldset className="space-y-2 text-sm">
          <legend className="font-medium">Chọn tài liệu gửi kèm</legend>

          {danhSach.map((taiLieu) => (
            <label key={taiLieu.taiLieuId} className="flex items-start gap-2">
              <input type="checkbox" name="taiLieuIds" value={taiLieu.taiLieuId} />
              <span className="break-all">{taiLieu.tenFileGoc || taiLieu.tenTaiLieu}</span>
            </label>
          ))}
        </fieldset>
      )}

      <label className="block text-sm font-medium">
        ID lãnh đạo duyệt (nếu hồ sơ cần chỉ định)
        <input
          name="lanhDaoDuyetId"
          type="number"
          min="1"
          step="1"
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
        />
      </label>

      <label className="block text-sm font-medium">
        Ghi chú trình
        <textarea
          name="ghiChuTrinh"
          rows={2}
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
        />
      </label>
    </fieldset>

    {loiTrinh && <p role="alert" className="text-sm text-red-800">{loiTrinh}</p>}

    <button
      type="submit"
      disabled={dangTrinh || daTrinh || dangTaiLen}
      className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
    >
      {dangTrinh ? 'Đang trình…' : daTrinh ? 'Đã trình' : 'Trình duyệt kế hoạch'}
    </button>
  </form>
)}
    </section>
  )
}
