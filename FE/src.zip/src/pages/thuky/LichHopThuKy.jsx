import { useEffect, useState } from 'react'

import {
  batDauCuocHop,
  layLichTheoCuocHop,
  taoLichHop,
} from '../../api/cuocHopApi.js'

const LOP_TRUONG = 'mt-1 w-full rounded-lg border border-slate-300 px-3 py-2'

const TEN_TRANG_THAI = {
  DE_XUAT: 'Đề xuất',
  DA_XAC_NHAN: 'Đã xác nhận',
  TU_CHOI: 'Từ chối',
  DA_HUY: 'Đã hủy',
  THAY_THE: 'Đã thay thế',
}

export default function LichHopThuKy({ cuocHopId, loaiHinh, token, onDaBatDau }) {
  const [danhSach, setDanhSach] = useState(null)
  const [loiTai, setLoiTai] = useState('')
  const [loiLuu, setLoiLuu] = useState('')
  const [thongBao, setThongBao] = useState('')
  const [dangLuu, setDangLuu] = useState(false)

    const [dangBatDau, setDangBatDau] = useState(false)
  const [loiBatDau, setLoiBatDau] = useState('')
  const hopTrucTiep = loaiHinh === 'TRUC_TIEP'

  useEffect(() => {
    const controller = new AbortController()

    layLichTheoCuocHop(cuocHopId, token, controller.signal)
      .then((duLieu) => {
        if (!controller.signal.aborted) setDanhSach(duLieu)
      })
      .catch((loi) => {
        if (!controller.signal.aborted) setLoiTai(loi.message)
      })

    return () => controller.abort()
  }, [cuocHopId, token])

  async function xuLyTaoLich(event) {
    event.preventDefault()
    if (dangLuu || danhSach === null) return

    const form = event.currentTarget
    const duLieuForm = new FormData(form)
    const thoiGianBatDau = duLieuForm.get('thoiGianBatDau')
    const thoiGianKetThuc = duLieuForm.get('thoiGianKetThuc')

    setLoiLuu('')
    setThongBao('')

    if (thoiGianKetThuc <= thoiGianBatDau) {
      setLoiLuu('Giờ kết thúc phải sau giờ bắt đầu.')
      return
    }

    setDangLuu(true)

    try {
      const lichMoi = await taoLichHop({
        cuocHopId,
        phongHopId: hopTrucTiep ? Number(duLieuForm.get('phongHopId')) : null,
        thoiGianBatDau,
        thoiGianKetThuc,
      }, token)

      setDanhSach((hienTai) => [lichMoi, ...hienTai])
      form.reset()
      setThongBao('Đã tạo lịch đề xuất.')
    } catch (loi) {
      setLoiLuu(loi.message)
    } finally {
      setDangLuu(false)
    }
  }

    async function xuLyBatDau() {
    if (dangBatDau || dangLuu) return

    setDangBatDau(true)
    setLoiBatDau('')

    try {
        const ketQua = await batDauCuocHop(cuocHopId, token)
        onDaBatDau({
        trangThai: ketQua.trangThai,
        buocXuLyHienTai: ketQua.buocXuLyHienTai,
        })
    } catch (loi) {
        setLoiBatDau(loi.message)
    } finally {
        setDangBatDau(false)
    }
    }

  return (
    <section className="space-y-4 border-t border-slate-200 pt-5">
      <h3 className="font-semibold">Lịch họp</h3>

      {loiTai ? (
        <p role="alert" className="text-sm text-red-800">{loiTai}</p>
      ) : danhSach === null ? (
        <p role="status" className="text-sm text-slate-600">Đang tải lịch…</p>
      ) : danhSach.length === 0 ? (
        <p className="text-sm text-slate-600">Cuộc họp chưa có lịch.</p>
      ) : (
        <ul className="divide-y divide-slate-200 text-sm">
          {danhSach.map((lich) => (
            <li key={lich.lichHopId} className="space-y-1 py-2">
              <p className="font-medium">
                Lịch #{lich.lichHopId} · {TEN_TRANG_THAI[lich.trangThai] || lich.trangThai}
              </p>
              <p className="text-slate-600">
                {lich.tenPhongHop || 'Trực tuyến'} ·{' '}
                {new Date(lich.thoiGianBatDau).toLocaleString('vi-VN')} –{' '}
                {new Date(lich.thoiGianKetThuc).toLocaleString('vi-VN')}
              </p>
            </li>
          ))}
        </ul>
      )}

      <form onSubmit={xuLyTaoLich} className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-sm font-medium">
            Bắt đầu
            <input name="thoiGianBatDau" type="datetime-local" required className={LOP_TRUONG} />
          </label>

          <label className="block text-sm font-medium">
            Kết thúc
            <input name="thoiGianKetThuc" type="datetime-local" required className={LOP_TRUONG} />
          </label>
        </div>

        {hopTrucTiep && (
          <label className="block text-sm font-medium">
            ID phòng họp
            <input name="phongHopId" type="number" min="1" step="1" required className={LOP_TRUONG} />
          </label>
        )}

        {loiLuu && <p role="alert" className="text-sm text-red-800">{loiLuu}</p>}
        {thongBao && <p role="status" className="text-sm text-emerald-800">{thongBao}</p>}

        <button
          type="submit"
          disabled={dangLuu || danhSach === null}
          className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          {dangLuu ? 'Đang lưu…' : 'Đề xuất lịch họp'}
        </button>
      </form>
      {danhSach?.some((lich) => lich.trangThai === 'DA_XAC_NHAN') && (
        <div className="space-y-2 border-t border-slate-200 pt-4">
            {loiBatDau && (
                <p role="alert" className="text-sm text-red-800">{loiBatDau}</p>
            )}

            <button
                type="button"
                onClick={xuLyBatDau}
                disabled={dangBatDau || dangLuu}
                className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            >
                {dangBatDau ? 'Đang bắt đầu…' : 'Bắt đầu cuộc họp'}
            </button>
        </div>
        )}
    </section>
  )
}