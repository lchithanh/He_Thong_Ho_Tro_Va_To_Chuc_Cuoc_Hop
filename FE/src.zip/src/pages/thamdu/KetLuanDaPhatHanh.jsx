import { useEffect, useState } from 'react'
import { layKetLuanDaPhatHanhCuaToi } from '../../api/ketLuanCuocHopApi.js'
import TaiLieuKetLuan from '../thuky/TaiLieuKetLuan.jsx'

export default function KetLuanDaPhatHanh({ token }) {
  const [danhSach, setDanhSach] = useState(null)
  const [loi, setLoi] = useState('')
  const [idDangXem, setIdDangXem] = useState(null)

  useEffect(() => {
    const controller = new AbortController()

    layKetLuanDaPhatHanhCuaToi(token, controller.signal)
      .then((duLieu) => {
        if (!controller.signal.aborted) setDanhSach(duLieu)
      })
      .catch((loiTai) => {
        if (!controller.signal.aborted) setLoi(loiTai.message)
      })

    return () => controller.abort()
  }, [token])

  return (
    <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5">
      <h2 className="text-lg font-bold">Kết luận đã phát hành</h2>

      {loi && <p role="alert" className="text-sm text-red-800">{loi}</p>}

      {!loi && danhSach === null && (
        <p role="status" className="text-sm text-slate-600">Đang tải kết luận…</p>
      )}

      {danhSach?.length === 0 && (
        <p className="text-sm text-slate-600">Bạn chưa có kết luận đã phát hành.</p>
      )}

      {danhSach?.map((ketLuan) => {
        const dangXem = idDangXem === ketLuan.ketLuanId

        return (
          <article key={ketLuan.ketLuanId} className="rounded-lg border border-slate-200 p-4">
            <h3 className="font-semibold">{ketLuan.tieuDe}</h3>
            <button
              type="button"
              aria-expanded={dangXem}
              onClick={() => setIdDangXem(dangXem ? null : ketLuan.ketLuanId)}
              className="mt-2 text-sm font-semibold text-emerald-800"
            >
              {dangXem ? 'Đóng chi tiết' : 'Xem kết luận'}
            </button>

            {dangXem && (
              <div className="mt-3 space-y-3">
                <p className="whitespace-pre-wrap text-sm">
                  {ketLuan.noiDung || 'Xem nội dung trong tệp đính kèm.'}
                </p>

                <TaiLieuKetLuan
                  cuocHopId={ketLuan.cuocHopId}
                  token={token}
                  choPhepTaiLen={false}
                />
              </div>
            )}
          </article>
        )
      })}
      
    </section>
  )
}