import { useState } from 'react'
import CalendarCheck2 from 'lucide-react/dist/esm/icons/calendar-check-2.mjs'
import ClipboardCheck from 'lucide-react/dist/esm/icons/clipboard-check.mjs'
import FileCheck2 from 'lucide-react/dist/esm/icons/file-check-2.mjs'
import FileClock from 'lucide-react/dist/esm/icons/file-clock.mjs'
import FileText from 'lucide-react/dist/esm/icons/file-text.mjs'
import Mail from 'lucide-react/dist/esm/icons/mail.mjs'
import Vote from 'lucide-react/dist/esm/icons/vote.mjs'
import BoCucChung from './BoCucChung.jsx'
import TongQuanCuocHop from '../pages/TongQuanCuocHop.jsx'
import DanhSachDeXuatThuKy from '../pages/thuky/DanhSachDeXuatThuKy.jsx'
import KeHoachChoDuyet from '../pages/pheduyet/KeHoachChoDuyet.jsx'
import XacNhanLichHop from '../pages/pheduyet/XacNhanLichHop.jsx'
import BienBanChoDuyet from '../pages/pheduyet/BienBanChoDuyet.jsx'
import KetLuanChoPhatHanh from '../pages/pheduyet/KetLuanChoPhatHanh.jsx'
import TaoBieuQuyet from '../pages/pheduyet/TaoBieuQuyet.jsx'
import PhanHoiLoiMoi from '../pages/thamdu/PhanHoiLoiMoi.jsx'
import BieuQuyetThamDu from '../pages/thamdu/BieuQuyetThamDu.jsx'
import KetLuanDaPhatHanh from '../pages/thamdu/KetLuanDaPhatHanh.jsx'

const MUC_THU_KY = [
  { id: 'de-xuat', ten: 'Đề xuất cuộc họp', Trang: DanhSachDeXuatThuKy, BieuTuong: FileText },
]

const MUC_PHE_DUYET = [
  { id: 'ke-hoach-cho-duyet', ten: 'Kế hoạch chờ duyệt', Trang: KeHoachChoDuyet, BieuTuong: FileClock },
  { id: 'xac-nhan-lich', ten: 'Xác nhận lịch họp', Trang: XacNhanLichHop, BieuTuong: CalendarCheck2 },
  { id: 'bien-ban-cho-duyet', ten: 'Biên bản chờ duyệt', Trang: BienBanChoDuyet, BieuTuong: ClipboardCheck },
  { id: 'ket-luan-cho-phat-hanh', ten: 'Kết luận chờ phát hành', Trang: KetLuanChoPhatHanh, BieuTuong: FileCheck2 },
  { id: 'tao-bieu-quyet', ten: 'Tạo biểu quyết', Trang: TaoBieuQuyet, BieuTuong: Vote },
]

const MUC_THAM_DU = [
  { id: 'loi-moi', ten: 'Lời mời họp', Trang: PhanHoiLoiMoi, BieuTuong: Mail },
  { id: 'tham-gia-bieu-quyet', ten: 'Biểu quyết và kết quả', Trang: BieuQuyetThamDu, BieuTuong: Vote },
  { id: 'ket-luan-da-phat-hanh', ten: 'Kết luận đã phát hành', Trang: KetLuanDaPhatHanh, BieuTuong: FileCheck2 },
]

export default function KhongGianLamViec({ nguoiDung, loi, onDangXuat }) {
  const { maVaiTro, token } = nguoiDung
  const [mucDangChon, setMucDangChon] = useState('tong-quan')
  let cacMuc = []

  if (maVaiTro === 'THU_KY') {
    cacMuc = [...MUC_THU_KY, ...MUC_THAM_DU]
  } else if (['CAN_BO', 'LANH_DAO'].includes(maVaiTro)) {
    cacMuc = [...MUC_PHE_DUYET, ...MUC_THAM_DU]
  }

  const mucHienTai = cacMuc.find((muc) => muc.id === mucDangChon)
  const TrangHienTai = mucHienTai?.Trang

  return (
    <BoCucChung
      nguoiDung={nguoiDung}
      onDangXuat={onDangXuat}
      dieuHuong={cacMuc}
      mucDangChon={mucDangChon}
      onChonMuc={setMucDangChon}
    >
      {loi && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          {loi}
        </p>
      )}

      {TrangHienTai ? (
        <TrangHienTai token={token} nguoiDung={nguoiDung} />
      ) : (
        <TongQuanCuocHop
          token={token}
          nguoiDung={nguoiDung}
          coTheMoDanhSach={cacMuc.some((muc) => muc.id === 'de-xuat')}
          onMoDanhSach={() => setMucDangChon('de-xuat')}
        />
      )}
    </BoCucChung>
  )
}
